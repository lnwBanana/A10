package com.a10strike;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** คลิกขวา = เรียกโจมตีที่จุดที่เล็ง | Shift+คลิกขวา = สลับอาวุธ */
public class StrikeRadioItem extends Item {
    private static final Map<UUID, Weapon> SELECTED = new HashMap<>();

    public StrikeRadioItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(level instanceof ServerLevel sl) || !(player instanceof ServerPlayer sp)) {
            return InteractionResult.SUCCESS;
        }
        Weapon w = SELECTED.getOrDefault(sp.getUUID(), Weapon.GUN);

        if (sp.isShiftKeyDown()) {
            w = w.next();
            SELECTED.put(sp.getUUID(), w);
            sp.displayClientMessage(Component.literal("§e[A-10] อาวุธ: §f" + w.label), true);
            return InteractionResult.SUCCESS;
        }

        Vec3 eye = sp.getEyePosition();
        Vec3 look = sp.getViewVector(1.0F);
        BlockHitResult hit = sl.clip(new ClipContext(eye, eye.add(look.scale(300)),
                ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, sp));
        if (hit.getType() == HitResult.Type.MISS) {
            sp.displayClientMessage(Component.literal("§c[A-10] เล็งไม่เจอพื้นภายใน 300 บล็อก"), true);
            return InteractionResult.SUCCESS;
        }
        StrikeManager.request(sl, sp, hit.getLocation(), w);
        return InteractionResult.SUCCESS;
    }
}
