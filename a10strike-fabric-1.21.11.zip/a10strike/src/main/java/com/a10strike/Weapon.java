package com.a10strike;

public enum Weapon {
    GUN("GAU-8 30mm", 20),
    ROCKET("Hydra-70 x16", 30),
    BOMB("Mk-82 x4", 60),
    NAPALM("Mk-77 Napalm x3", 60),
    CLUSTER("CBU-87 Cluster x2", 60),
    MAVERICK("AGM-65 Maverick x2", 40);

    public final String label;
    public final int cooldownSec;

    Weapon(String label, int cooldownSec) {
        this.label = label;
        this.cooldownSec = cooldownSec;
    }

    public Weapon next() {
        Weapon[] v = values();
        return v[(ordinal() + 1) % v.length];
    }
}
