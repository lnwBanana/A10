package com.a10strike;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * จัดการภารกิจ A-10 ทั้งหมด (ฝั่งเซิร์ฟเวอร์ล้วน ใช้ได้ทั้ง singleplayer)
 * เครื่องบินยังเป็น "เส้นควัน + เสียง" ก่อน — เฟสถัดไปค่อยใส่โมเดล GeckoLib
 */
public final class StrikeManager {
    private StrikeManager() {}

    // ================= ตั้งค่า =================
    static final int DELAY = 120;            // รอหลังเรียก (tick) = 6 วิ
    static final int MAX_ACTIVE = 2;         // ภารกิจพร้อมกันสูงสุด
    static final double PATH_BACK = 200;     // ระยะเริ่มบินก่อนถึงเป้า
    static final double SPEED = 3.0;         // บล็อก/tick
    static final double ALT = 55;            // ความสูงเหนือเป้า
    static final boolean PROTECT_PLAYERS = true; // มีผู้เล่นใกล้จุดตก -> ไม่ทำลายบล็อก (เอฟเฟกต์ยังอยู่)
    // ===========================================

    private static final List<Strike> STRIKES = new ArrayList<>();
    private static final List<Ord> ORD = new ArrayList<>();
    private static final List<Ord> PENDING = new ArrayList<>();
    private static final Map<UUID, EnumMap<Weapon, Long>> READY = new HashMap<>();

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> tick());
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            STRIKES.clear();
            ORD.clear();
            PENDING.clear();
            READY.clear();
        });
    }

    public static void request(ServerLevel l, ServerPlayer p, Vec3 target, Weapon w) {
        long now = l.getGameTime();
        EnumMap<Weapon, Long> map = READY.computeIfAbsent(p.getUUID(), k -> new EnumMap<>(Weapon.class));
        long ready = map.getOrDefault(w, 0L);
        if (now < ready) {
            p.displayClientMessage(Component.literal("§c[A-10] " + w.label + " กำลังเติมอาวุธ อีก " + ((ready - now + 19) / 20) + " วิ"), true);
            return;
        }
        if (STRIKES.size() >= MAX_ACTIVE) {
            p.displayClientMessage(Component.literal("§c[A-10] มีภารกิจเยอะเกินไป รอให้จบก่อน"), true);
            return;
        }
        map.put(w, now + w.cooldownSec * 20L);

        Vec3 look = p.getViewVector(1.0F);
        double len = Math.hypot(look.x, look.z);
        double dx = len < 1e-4 ? 0 : look.x / len;
        double dz = len < 1e-4 ? 1 : look.z / len;

        STRIKES.add(new Strike(l, p.getUUID(), target, dx, dz, w));
        p.displayClientMessage(Component.literal("§a[Hog 1-1] Copy. " + w.label + " inbound ~6 วิ — ปักควันไว้แล้ว หลบด้วย!"), false);
        snd(l, SoundEvents.BEACON_ACTIVATE, p.position(), 1f, 1.6f);
    }

    private static void tick() {
        STRIKES.removeIf(s -> {
            try {
                s.tick();
            } catch (Throwable e) {
                A10Strike.LOGGER.error("strike failed", e);
                s.done = true;
            }
            return s.done;
        });
        ORD.removeIf(o -> {
            try {
                o.tick();
            } catch (Throwable e) {
                A10Strike.LOGGER.error("ordnance failed", e);
                o.done = true;
            }
            return o.done;
        });
        ORD.addAll(PENDING);
        PENDING.clear();
    }

    // ================= ตัวช่วย =================
    static void fx(ServerLevel l, ParticleOptions p, Vec3 v, int n, double spread, double speed) {
        l.sendParticles(p, v.x, v.y, v.z, n, spread, spread, spread, speed);
    }

    static void snd(ServerLevel l, SoundEvent s, Vec3 v, float vol, float pitch) {
        l.playSound(null, v.x, v.y, v.z, s, SoundSource.BLOCKS, vol, pitch);
    }

    static Vec3 ground(ServerLevel l, double x, double z) {
        int y = l.getHeight(Heightmap.Types.MOTION_BLOCKING, (int) Math.floor(x), (int) Math.floor(z));
        return new Vec3(x, y, z);
    }

    static boolean playerNear(ServerLevel l, Vec3 p, double r) {
        for (ServerPlayer pl : l.players()) {
            if (pl.distanceToSqr(p.x, p.y, p.z) < r * r) return true;
        }
        return false;
    }

    /** ดาเมจตรงๆ ใส่มอนสเตอร์/สัตว์ (ไม่ยุ่งกับผู้เล่น) ยิ่งใกล้ศูนย์กลางยิ่งแรง */
    static void splash(ServerLevel l, Vec3 p, double r, float dmg) {
        AABB box = new AABB(p, p).inflate(r);
        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, box, x -> !(x instanceof Player))) {
            double d = e.position().distanceTo(p);
            if (d > r) continue;
            e.hurtServer(l, l.damageSources().explosion(null, null), (float) (dmg * (1 - d / r)));
        }
    }

    static void fireball(ServerLevel l, Vec3 p, float power) {
        int n = (int) (power * 6);
        fx(l, ParticleTypes.FLAME, p.add(0, 1, 0), n, power * 0.35, 0.12);
        fx(l, ParticleTypes.LARGE_SMOKE, p.add(0, 1.5, 0), n, power * 0.4, 0.06);
        if (power >= 2) fx(l, ParticleTypes.EXPLOSION_EMITTER, p, 1, 0, 0);
        if (power >= 4) fx(l, ParticleTypes.LAVA, p.add(0, 2, 0), n * 2, power * 0.3, 0.2);
    }

    static void blast(ServerLevel l, Vec3 p, float power, boolean fire, boolean breakBlocks,
                      double splashR, float splashDmg, double safeR) {
        boolean safe = PROTECT_PLAYERS && playerNear(l, p, safeR);
        if (!safe && breakBlocks) {
            l.explode(null, p.x, p.y, p.z, power, fire, Level.ExplosionInteraction.TNT);
        } else {
            snd(l, SoundEvents.LIGHTNING_BOLT_THUNDER, p, 2f, 1.6f);
        }
        fireball(l, p, power);
        splash(l, p, splashR, splashDmg);
    }

    static void napalmFire(ServerLevel l, Vec3 c, double r, Random rnd) {
        boolean safe = PROTECT_PLAYERS && playerNear(l, c, r + 6);
        fx(l, ParticleTypes.FLAME, c.add(0, 1, 0), 120, r * 0.5, 0.15);
        AABB box = new AABB(c, c).inflate(r);
        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, box, x -> !(x instanceof Player))) {
            e.setRemainingFireTicks(200);
        }
        if (safe) return;
        for (int i = 0; i < 45; i++) {
            double x = c.x + (rnd.nextDouble() * 2 - 1) * r;
            double z = c.z + (rnd.nextDouble() * 2 - 1) * r;
            Vec3 g = ground(l, x, z);
            BlockPos pos = BlockPos.containing(g);
            if (l.getBlockState(pos).isAir() && !l.getBlockState(pos.below()).isAir()) {
                l.setBlockAndUpdate(pos, Blocks.FIRE.defaultBlockState());
            }
        }
    }

    // ================= ภารกิจ (เครื่องบิน 1 ลำ) =================
    private static final class Strike {
        final ServerLevel l;
        final UUID owner;
        final Vec3 target;
        final double dx, dz;
        final Weapon w;
        final Random rnd = new Random();
        int t = 0;
        boolean done = false;
        int fired = 0;

        Strike(ServerLevel l, UUID owner, Vec3 target, double dx, double dz, Weapon w) {
            this.l = l;
            this.owner = owner;
            this.target = target;
            this.dx = dx;
            this.dz = dz;
            this.w = w;
        }

        void radio(String s) {
            Player p = l.getPlayerByUUID(owner);
            if (p != null) p.displayClientMessage(Component.literal(s), false);
        }

        Vec3 aim(double s, double side) {
            double x = target.x + dx * s - dz * side;
            double z = target.z + dz * s + dx * side;
            return ground(l, x, z);
        }

        void tick() {
            if (!l.hasChunkAt(BlockPos.containing(target))) {
                done = true;
                return;
            }
            // ช่วงรอ: ควันสัญญาณที่เป้า
            if (t < DELAY) {
                if (t % 5 == 0) fx(l, ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, target.add(0, 0.3, 0), 2, 0.1, 0.02);
                if (t == DELAY - 40) radio("§a[Hog 1-1] Tally smoke. 30 วิ... เอ้ย 2 วิ จะถึงแล้ว!");
                t++;
                return;
            }

            int k = t - DELAY;
            double s = SPEED * k - PATH_BACK;
            Vec3 plane = new Vec3(target.x + dx * s, target.y + ALT, target.z + dz * s);

            // เครื่องบิน = เส้นควัน + ไฟท้าย + เสียงเครื่องยนต์
            fx(l, ParticleTypes.CLOUD, plane, 3, 0.25, 0);
            fx(l, ParticleTypes.LARGE_SMOKE, plane, 2, 0.2, 0);
            fx(l, ParticleTypes.FLAME, plane.subtract(dx * 2, 0, dz * 2), 1, 0.05, 0.01);
            if (k % 6 == 0) snd(l, SoundEvents.ENDER_DRAGON_FLAP, plane, 8f, 0.5f);

            switch (w) {
                case GUN -> gun(s, plane);
                case ROCKET -> rockets(s, plane);
                case BOMB, NAPALM -> bombs(s, plane, w == Weapon.BOMB ? 4 : 3, w == Weapon.BOMB ? Ord.Kind.BOMB : Ord.Kind.NAPALM);
                case CLUSTER -> bombs(s, plane, 2, Ord.Kind.CLUSTER);
                case MAVERICK -> mavericks(s, plane);
            }

            if (s > 130) {
                done = true;
                radio("§a[Hog 1-1] Off target, climbing out. Good hits!");
            }
            t++;
        }

        void gun(double s, Vec3 plane) {
            if (s < -40 || s > 35) return;
            if (s < -38) radio("§e[Hog 1-1] Guns, guns, guns!");
            Vec3 center = aim(s + 20, 0);
            snd(l, SoundEvents.FIREWORK_ROCKET_BLAST, center, 3f, 0.5f + rnd.nextFloat() * 0.2f);
            for (int i = 0; i < 8; i++) {
                double sa = s + 20 + (rnd.nextDouble() - 0.5) * 6;
                double side = (rnd.nextDouble() - 0.5) * 5;
                Vec3 g = aim(sa, side);
                if (i % 2 == 0) tracer(plane, g);
                if (rnd.nextInt(5) == 0) {
                    blast(l, g, 1.3f, rnd.nextDouble() < 0.08, true, 3.0, 12.75f, 6);
                } else {
                    fx(l, ParticleTypes.POOF, g.add(0, 0.5, 0), 2, 0.3, 0.05);
                    splash(l, g, 2.5, 12.75f);
                }
            }
        }

        void tracer(Vec3 from, Vec3 to) {
            for (int j = 1; j <= 6; j++) {
                Vec3 p = from.add(to.subtract(from).scale(j / 6.0));
                fx(l, ParticleTypes.END_ROD, p, 1, 0, 0);
            }
        }

        void rockets(double s, Vec3 plane) {
            if (s < -45 || s > 30) return;
            int expected = (int) Math.min(16, Math.floor((s + 45) / 75.0 * 16) + 1);
            while (fired < expected) {
                fired++;
                double side = (rnd.nextDouble() - 0.5) * 18;
                Vec3 end = aim(s + 30 + (rnd.nextDouble() - 0.5) * 10, side);
                PENDING.add(new Ord(l, Ord.Kind.ROCKET, plane, end, rnd));
                snd(l, SoundEvents.FIREWORK_ROCKET_LAUNCH, plane, 4f, 0.6f);
            }
        }

        void bombs(double s, Vec3 plane, int n, Ord.Kind kind) {
            double step = n > 1 ? 75.0 / (n - 1) : 0;
            while (fired < n) {
                double impactS = -40 + fired * step;
                if (s < impactS - SPEED * 22) break;
                fired++;
                Vec3 end = aim(impactS, (rnd.nextDouble() - 0.5) * 3);
                PENDING.add(new Ord(l, kind, plane, end, rnd));
                if (fired == 1) radio("§e[Hog 1-1] Rifle! Bombs away!");
            }
        }

        void mavericks(double s, Vec3 plane) {
            while (fired < 2 && s >= -30 + fired * 20) {
                fired++;
                Vec3 end = aim(0, 0);
                PENDING.add(new Ord(l, Ord.Kind.MAV, plane, end, rnd));
                snd(l, SoundEvents.FIREWORK_ROCKET_LAUNCH, plane, 4f, 0.8f);
                radio("§e[Hog 1-1] Maverick away!");
            }
        }
    }

    // ================= กระสุน/จรวด/ระเบิดที่กำลังบิน =================
    private static final class Ord {
        enum Kind { ROCKET, BOMB, NAPALM, CLUSTER, BOMBLET, MAV }

        final ServerLevel l;
        final Kind kind;
        final Vec3 start, end;
        final Random rnd;
        Vec3 pos;
        Vec3 vel = Vec3.ZERO;
        LivingEntity tgt;
        int age = 0;
        final int life;
        boolean done = false;

        Ord(ServerLevel l, Kind kind, Vec3 start, Vec3 end, Random rnd) {
            this.l = l;
            this.kind = kind;
            this.start = start;
            this.end = end;
            this.rnd = rnd;
            this.pos = start;
            this.life = switch (kind) {
                case BOMB, NAPALM, CLUSTER -> 22;
                case BOMBLET -> 10;
                case ROCKET -> 80;
                case MAV -> 120;
            };
            if (kind == Kind.MAV) {
                double best = Double.MAX_VALUE;
                AABB box = new AABB(end, end).inflate(40);
                for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, box, x -> x instanceof Enemy && x.isAlive())) {
                    double d = e.position().distanceTo(end);
                    if (d < best) {
                        best = d;
                        tgt = e;
                    }
                }
                vel = end.subtract(start).normalize().scale(3.2);
            }
        }

        void tick() {
            age++;
            switch (kind) {
                case ROCKET -> {
                    Vec3 d = end.subtract(pos);
                    double dist = d.length();
                    if (dist <= 4.0 || age > life) {
                        blast(l, end, 4f, rnd.nextDouble() < 0.3, true, 7, 60f, 11);
                        done = true;
                        return;
                    }
                    pos = pos.add(d.scale(4.0 / dist));
                    fx(l, ParticleTypes.SMOKE, pos, 3, 0.05, 0.01);
                    fx(l, ParticleTypes.FLAME, pos, 1, 0.02, 0.01);
                    fx(l, ParticleTypes.LARGE_SMOKE, pos, 1, 0.05, 0);
                }
                case BOMB, NAPALM, CLUSTER, BOMBLET -> {
                    double u = Math.min(1.0, age / (double) life);
                    pos = new Vec3(start.x + (end.x - start.x) * u,
                            start.y + (end.y - start.y) * u * u,
                            start.z + (end.z - start.z) * u);
                    fx(l, ParticleTypes.SMOKE, pos, kind == Kind.BOMBLET ? 1 : 3, 0.05, 0);
                    if (age == 1 && kind != Kind.BOMBLET) snd(l, SoundEvents.FIREWORK_ROCKET_LAUNCH, pos, 3f, 0.4f);
                    if (kind == Kind.CLUSTER && u >= 0.8) {
                        burst();
                        done = true;
                        return;
                    }
                    if (u >= 1.0) {
                        drop();
                        done = true;
                    }
                }
                case MAV -> {
                    Vec3 aim = (tgt != null && tgt.isAlive())
                            ? tgt.position().add(0, tgt.getBbHeight() * 0.5, 0) : end;
                    Vec3 want = aim.subtract(pos).normalize();
                    vel = vel.scale(0.7).add(want.scale(3.2 * 0.3)).normalize().scale(3.2);
                    pos = pos.add(vel);
                    fx(l, ParticleTypes.SMOKE, pos, 3, 0.05, 0.01);
                    fx(l, ParticleTypes.FLAME, pos, 1, 0.02, 0.01);
                    if (pos.distanceTo(aim) < 2.5 || age > life || !l.getBlockState(BlockPos.containing(pos)).isAir()) {
                        blast(l, pos, 5f, true, true, 8, 80f, 11);
                        done = true;
                    }
                }
            }
        }

        void drop() {
            switch (kind) {
                case BOMB -> blast(l, end, 11f, rnd.nextDouble() < 0.4, true, 18, 400f, 26);
                case NAPALM -> {
                    blast(l, end, 2.5f, false, true, 10, 40f, 14);
                    napalmFire(l, end, 10, rnd);
                }
                case BOMBLET -> blast(l, end, 2.2f, rnd.nextDouble() < 0.2, true, 5, 25f, 8);
                default -> {
                }
            }
        }

        void burst() {
            snd(l, SoundEvents.LIGHTNING_BOLT_THUNDER, pos, 3f, 1.2f);
            fx(l, ParticleTypes.EXPLOSION, pos, 4, 1.5, 0);
            for (int i = 0; i < 14; i++) {
                double ang = rnd.nextDouble() * Math.PI * 2;
                double r = 3 + rnd.nextDouble() * 12;
                Vec3 g = ground(l, end.x + Math.cos(ang) * r, end.z + Math.sin(ang) * r);
                PENDING.add(new Ord(l, Kind.BOMBLET, pos, g, rnd));
            }
        }
    }
}
