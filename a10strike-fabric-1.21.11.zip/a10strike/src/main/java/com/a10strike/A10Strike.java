package com.a10strike;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier; // ถ้า compile ไม่ผ่าน ลองเปลี่ยนเป็น net.minecraft.resources.ResourceLocation
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class A10Strike implements ModInitializer {
    public static final String ID = "a10strike";
    public static final Logger LOGGER = LoggerFactory.getLogger(ID);
    public static Item STRIKE_RADIO;

    @Override
    public void onInitialize() {
        Identifier id = Identifier.fromNamespaceAndPath(ID, "strike_radio");
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
        STRIKE_RADIO = Registry.register(BuiltInRegistries.ITEM, key,
                new StrikeRadioItem(new Item.Properties().setId(key).stacksTo(1)));

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
                .register(entries -> entries.accept(STRIKE_RADIO));

        StrikeManager.init();
        LOGGER.info("A-10 Strike loaded. Hog 1-1 standing by.");
    }
}
