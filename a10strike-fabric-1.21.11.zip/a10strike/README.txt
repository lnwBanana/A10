A-10 Strike (Fabric 1.21.11, Mojang mappings)

วิธี build
1) ไปที่ https://fabricmc.net/develop เลือก 1.21.11 (Mojang mappings) แล้วโหลด template
2) เอาโฟลเดอร์ gradle/, gradlew, gradlew.bat จาก template มาวางในโปรเจกต์นี้ (ไฟล์ wrapper ผมสร้างให้ไม่ได้)
3) ติดตั้ง JDK 21 แล้วรัน:  ./gradlew build   (Windows: gradlew.bat build)
4) เอา build/libs/a10strike-0.1.0.jar + Fabric API ใส่โฟลเดอร์ mods
5) ในเกม: /give @s a10strike:strike_radio
   คลิกขวา = เรียกโจมตีที่จุดที่เล็ง | Shift+คลิกขวา = สลับอาวุธ

ถ้า compile error:
- net.minecraft.resources.Identifier ไม่พบ -> เปลี่ยนเป็น ResourceLocation (A10Strike.java)
- ถ้าเวอร์ชันใน gradle.properties ไม่มี ให้ใช้เลขล่าสุดจาก fabricmc.net/develop
